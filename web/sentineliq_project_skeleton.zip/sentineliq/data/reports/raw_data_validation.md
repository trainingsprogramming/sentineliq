# Raw Data Validation Report

**Status:** PASSED
**Run Date:** Today
**Data Directory:** `/home/nithe73/Desktop/Project/sentineliq/data/raw`

## Summary of Dataset Metadata
- **Dataset Version:** `v1.0.0`
- **Client:** `NexaTel Communications Ltd.`
- **Service Provider:** `Asterion Digital Operations Services Pvt. Ltd.`

## File Counts & Validation Summary
| Category | Expected Extension | Valid Files Count | Status |
|---|---|---|---|
| Policies | `.pdf` | 48 | PASS |
| Release Notes | `.docx` | 21 | PASS |
| Logs | `.log` | 22 | PASS |
| Docs (Architecture & Decisions) | `.md`/`.docx` | 27 | PASS |

## Bad Files Detected
We detected the following files that violate extension rules, are zero-byte placeholders, or contain corrupted structure:
- `release_notes/deployment_checklist.txt (invalid extension)`
- `logs/session_events_recovery.json (invalid extension)`
- `docs/escalation_runbook_scratch.md (zero-byte file)`

## Errors
- None

## Warnings
- None
