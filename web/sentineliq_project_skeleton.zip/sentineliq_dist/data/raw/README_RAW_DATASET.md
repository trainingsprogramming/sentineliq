# NexaTel/Asterion Raw Dataset v002

Externally provided raw data for SentinelIQ. The application must not generate this data during normal execution.

Coverage: 2021-06-01 through 2026-05-31
Service Provider: Asterion Digital Operations Services Pvt. Ltd.
Client: NexaTel Communications Ltd.
Contract: NexaTel Five-Year OSS/BSS Managed Operations Agreement

This dataset intentionally contains duplicates, bad files, missing values, PII-like test values, SLA breaches, incident links, release links, API snapshots, and prompt-injection-like text so the project can test production behavior.
